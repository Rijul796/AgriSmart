//
//  HeaderView.swift
//  home_page_apex
//
//  Created by student-2 on 10/12/24.
//

import UIKit

class HeaderView: UICollectionReusableView {
    
       @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var viewAllButton: UIButton!

}
