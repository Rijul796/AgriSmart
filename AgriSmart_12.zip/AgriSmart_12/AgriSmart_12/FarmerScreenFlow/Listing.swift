//
//  Listing.swift
//  home_page_apex
//
//  Created by student-2 on 10/12/24.
//

struct Listing {
    let title: String
    let stock: String
    let imageName: String
}

let listings = [
    Listing(title: "Organic Wheat", stock: "50%", imageName: "hph-1"),
    Listing(title: "Organic Corn", stock: "40%", imageName: "hph-2"),
    Listing(title: "Organic Peas", stock: "50%", imageName: "hph-4"),
    Listing(title: "Organic Pattato", stock: "Sold Out", imageName: "hph-3"),

]

let ordersOverview = ["Order Overview"]


