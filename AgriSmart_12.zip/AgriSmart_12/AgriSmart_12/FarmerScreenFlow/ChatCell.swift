//
//  ChatCell.swift
//  home_page_apex
//
//  Created by student-2 on 12/12/24.
//

import UIKit

class ChatCell: UITableViewCell {
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
}
