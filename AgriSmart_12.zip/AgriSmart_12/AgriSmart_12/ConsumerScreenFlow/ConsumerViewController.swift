//
//  ConsumerViewController.swift
//  AgriSmart_12
//
//  Created by student-2 on 17/01/25.
//


import UIKit

class ConsumerViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup if needed
    }
}
