//
//  ConsumerChatCell.swift
//  AgriSmart_12
//
//  Created by student-2 on 18/01/25.
//


import UIKit

class ConsumerChatCell: UITableViewCell {
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
}
