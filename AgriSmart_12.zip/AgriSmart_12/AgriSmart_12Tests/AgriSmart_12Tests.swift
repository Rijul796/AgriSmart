//
//  AgriSmart_12Tests.swift
//  AgriSmart_12Tests
//
//  Created by student-2 on 02/12/24.
//

import Testing
@testable import AgriSmart_12

struct AgriSmart_12Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
